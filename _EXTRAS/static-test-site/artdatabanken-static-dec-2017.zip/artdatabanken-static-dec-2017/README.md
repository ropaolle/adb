# artdatabanken

[JS-XLSX](https://github.com/SheetJS/js-xlsx)-projekt som skapar pdf.filer från Pappas Excelbaserade artdatabank.

![Exampl](/src/lib/img/example-small.jpg)
<!-- ![Exampl](/src/lib/img/example.png) -->

### Info
Format document: Ctrl+Shft+i
